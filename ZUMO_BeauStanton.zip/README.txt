Notes for PT:
-I have achieved the first 4 tasks.

-For the first task I split the movement functionality of W from the others. I did this so that I could
	have the code for search for walls (task 2/3) but not have walls searched for with other ASD
	movements.

-I used the min readings of the sensor callibration so the zumo can work in multiple light conditions.

-I hard coded the room entry and exit movements in task 4 as I personally struggled to get the compass
	code to work effectivly but I still feel the solution is acceptable for the problem.

-Occasionally an issue appears when searching a room of the distance recieved being 0cm on the first reading
	triggering a response that an object is in the room even if it isn't. I added a statement that an
	object should also be > 2cm to go around this.

-Another issue is that of room number not incrementing correctly. I have no idea how this would be fixed as
	it appears as if it should work correctly.

-Throughout I used a string to represent different AI states to help neaten the code and make controlling
	the robot easier.

CH = C
PANID = 3332